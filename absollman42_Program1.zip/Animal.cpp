#include "Animal.h"

// Print animal's details
void Animal::printAnimalDetatils(){

    cout << "\t\t\t\tAnimal Name: " << name << endl;
    cout << "\t\t\t\tBreed: " << breed << endl;
    cout << "\t\t\t\tAge: " << age << endl;
    cout << "\t\t\t\tHabitat: " << habitat << endl;
    cout << "\t\t\t\tHealthy: " << healthy << endl;

}

// Prints the animal's details to a file
void Animal::printAnimalDetatilsToFile(ofstream &x){

   
    x << "\tAnimal Name: " << name << endl;
    x << "\tBreed: " << breed << endl;
    x << "\tAge: " << age << endl;
    x << "\tHabitat: " << habitat << endl;
    x << "\tHealthy: " << healthy << endl << endl;

}

// Returns the animal's name
string Animal::getAnimalName(){
    return name;
}

// Constructor
Animal::Animal(string name, string breed, int age, string habitat, bool healthy){
    this->name = name;
    this->breed = breed;
    this->age = age;
    this->habitat = habitat;
    this->healthy = healthy;
}
// Destructor (no dynamically allocated memory to destroy)
Animal::~Animal(){
    
        cout << "Goodbye " << getAnimalName() << " I will see you later!\n\n";
    
}

