/*************************************************************
 * Filename: Zoo.h
 * Author: Anissa Sollman
 * Date: 01/23/2025
 * Purpose: Zoo header file contains the Zoo class
**************************************************************/

#ifndef Zoo_h
#define Zoo_h

using namespace std;

// Libraries
#include <iostream>
#include <string>
#include <fstream>
#include "Animal.h"

// Zoo class
class Zoo{
    // Attributes
    private:
        int maxAnimals; // Max animals the zoo holds (size of array)
        int numAnimals; // Actual number of animals in the zoo
        Animal**animalArray; // Pointer to an array of pointers which will point to a single animal object
        
    // Member Functions
    public:
        void setMaxAnimals(int);
        void resizeAnimalArray();
        void addAnimalToArray();
        void displayAnimals();
        void displayAnimalNames();
        void loadAnimalsFromFile(string);
        void removeAnimalFromArray();
        void saveToFile(string);
        Zoo(int);
        ~Zoo();
};
#endif