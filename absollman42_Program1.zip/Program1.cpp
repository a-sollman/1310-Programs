/*************************************************************
 * Filename: Program1.cpp
 * Author: Anissa Sollman
 * Date: 01/23/2025
 * Purpose: Program 1
**************************************************************/

#include "Zoo.h"
#include "Animal.h"
#include <limits>

void zooMenu(int&);

int main(){

    // Variables
    int animalNum = 0;
    int choice = 0;
    string fileName;

    // Intro
    cout << "How many animals can your zoo hold?\n";
    cin >> animalNum;
    // Validate user input
    while(animalNum < 1 || !cin){ 
        cin.clear(); //clears the error state
		//line below ignores the rest of the current line, up to '\n' or EOF - whichever comes first
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "You have to have at least one animal available in your zoo.\n\n";
        cout << "How many animals can your zoo hold?\n";
        cin >> animalNum;
    }

    Zoo* zooAnimals = new Zoo(animalNum);     // Dynamically allocate a Zoo Object

    zooMenu(choice);   // Display the zoo menu and get user's choice

    do{
        // User Menu Choice
        switch(choice){

            case 1:  // User wants to load animals from file
            cout << "What is the name of the file? (example.txt):  ";
            cin.ignore();
            getline(cin, fileName);
            zooAnimals->loadAnimalsFromFile(fileName);
            zooMenu(choice);
            break;


            case 2:  // User wants to save animals to a file
            cout << "What do you want to name the file? (example.txt): ";
            cin.ignore();
            getline(cin, fileName);
            zooAnimals->saveToFile(fileName);
            zooMenu(choice);
            break;


            case 3:  // User wants to add an animal to zoo
            zooAnimals->addAnimalToArray();
            zooMenu(choice);
            break;


            case 4:   // User wants to remove an animal from the zoo
            zooAnimals->removeAnimalFromArray();
            zooMenu(choice);
            break;


            case 5:   // User wants to display all animals in the zoo
            zooAnimals->displayAnimals();
            zooMenu(choice);
            break;


            case 6:  // User wants to remove all animals from the zoo and end program
            zooAnimals->~Zoo();
            return 0;
            break;
        
            }
        }while(choice <= 6);

        return 0;
}

// Displays zoo menu and validates menu choice
void zooMenu(int &choice){

    cout << "\nWhat would you like to do?\n";
    cout << "1. Load animals from file.\n";
    cout << "2. Save animals to a file.\n";
    cout << "3. Add animals.\n";
    cout << "4. Remove an animal.\n";
    cout << "5. Display all animals.\n";
    cout << "6. Remove ALL animals from this zoo and end program.\n";
    cout << "CHOOSE 1-6: ";
    cin >> choice;
    // Validate User Input
    while(choice < 1 || choice > 6){
        cout << "\nPlease enter a valid menu option: ";
        cin >> choice;
    }
    cout << endl;

}