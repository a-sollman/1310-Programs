/*************************************************************
 * Filename: Animal.h
 * Author: Anissa Sollman
 * Date: 01/23/2025
 * Purpose: Animal header file contains the Animal class
**************************************************************/
#ifndef Animal_h
#define Animal_h

using namespace std;

// Libraries
#include <iostream>
#include <string>
#include <fstream>

// Animal class
class Animal{

    // Attributes (Characteristics of a single animal)
    private:
    string name;
    string breed;
    int age;
    string habitat;
    bool healthy;

    // Member Functions
    public:
    void printAnimalDetatils();
    void printAnimalDetatilsToFile(ofstream&);
    string getAnimalName();
    
    // Constructor
    Animal(string name, string breed, int age, string habitat, bool healthy);
    // Destructor (no dynamically allocated memory to destroy)
    ~Animal();
};

#endif