#include "Zoo.h"
#include "Animal.h"
#include <limits>

// Default Constructor
Zoo::Zoo(int maxAnimals){
    this->maxAnimals = maxAnimals;
    this->numAnimals = 0;
    this->animalArray = new Animal*[maxAnimals]; 
    // animalArray points to an array of pointers
    // Example: animalArray[0] will point to the first animal object in our array
}
// Destructor
Zoo::~Zoo(){  // Destructor
    for(int i = 0; i < numAnimals; i++){
        delete animalArray[i];
    }
    delete animalArray;
    cout << "Zoo destructor: Released memory for each animal in the zoo array and the array itself.";
}
// Sets maxAnimals to however many animals the User inputs
void Zoo::setMaxAnimals(int x){
    this->maxAnimals = x;
}

// Loads animals from a file into our animalArray
void Zoo::loadAnimalsFromFile(string x){

    // Variables
    ifstream infile;
    string input;
    string name;
    string breed;
    int age = 0;
    string habitat;
    bool health;
    int counter = 0;

    infile.open(x);  // Opens file at the beginning
    if(infile.is_open()){
            // Outputs names of animals from file
            while(!infile.eof()){
                while(getline(infile, input, '\n')){
                        name = input;   // Stores name in array
                        cout << name << " was added to the animal zoo!\n";
                    
                    getline(infile, input, '\n');    // Stores breed
                        breed = input;
                    
                    getline(infile, input, '\n');   // Stores age
                        age = stoi(input);
                    

                    getline(infile, input, '\n');    // Stores habitat
                        habitat = input;
                    
                    getline(infile, input, '\n');   // Stores health
                        if(stoi(input) == 0){
                            health = 0;
                        }
                        else{
                            health = 1;
                        }
                    
                    counter++; // How many animals are added to the zoo from the file
                    
                    Animal* animal = new Animal(name, breed, age, habitat, health);
                    animalArray[this->numAnimals] = animal;    // Store animal's characteristics in the correct pointer of the animalArray
                    this->numAnimals++;   // Increment numAnimals for each Animal added
                    // if numAnimals is equal to maxAnimals, call resizeAnimalArray function
                    if(this->numAnimals == this->maxAnimals){
                        resizeAnimalArray();
                    }
                }   
            }
        
            cout << "\n" << counter << " animals were read from the file and added to your Animal zoo.\n";
    }

    else{
        cout << "\nFile could not be opened.";
    }
    infile.close();
}


// Creates new animal array of double the size and copies the contents from original array
void Zoo::resizeAnimalArray(){

    Animal **doubleAnimalArray = new Animal*[(2 * this->maxAnimals)]; // Creating new array of Animal object pointers
    
    cout << "\nResizing AnimalArray from " << this->numAnimals << " to " << (this->numAnimals*2) << endl;    
    // For each element in doubleAnimalArray, copy information from animal
    for(int i = 0; i < (2 * this->maxAnimals); i++){
        doubleAnimalArray[i] = animalArray[i];
    }
    delete [] animalArray;
    animalArray = doubleAnimalArray;
    this->maxAnimals *= 2; // Our zoo now holds double the amount of animals
}

// User wants to add an individual animal to the zoo
void Zoo::addAnimalToArray(){

    // Variables
    string name = "";
    string breed = "";
    int age = 0;
    string habitat = "";
    bool health = 0;

    // Asking user the characteristics of the animal
    cout << "Animal Name: ";
    cin.ignore();
    getline(cin, name);

    cout << "\nBreed: ";
    getline(cin, breed);

    cout << "\nAge: ";
    cin >> age;
    while(age < 0 || !cin){
        cin.clear(); //clears the error state
		//line below ignores the rest of the current line, up to '\n' or EOF - whichever comes first
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Please enter a valid age: ";
        cin >> age;
        }

    cout << "\nHabitat: ";
    cin.ignore();
    getline(cin, habitat);

    cout << "\nHealthy? : ";
    cin >> health;
    while(health < 0 || health > 1 || !cin){
        cin.clear(); //clears the error state
		//line below ignores the rest of the current line, up to '\n' or EOF - whichever comes first
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Please enter a valid health level: ";
        cin >> health;
        }

    Animal *addOneAnimal = new Animal(name, breed, age, habitat, health); // Dynamicaly allocate new Animal object, sending the characteristics
    animalArray[numAnimals] = addOneAnimal; // Adding our animal to the last element of our array
    numAnimals++;
}

// User wants to the display the animals' details
void Zoo::displayAnimals(){

    if(this->numAnimals == 0){
        cout << "There are no animals in your zoo yet." << endl;
    }
    else{
        // Loop through animalArray and enter the printAnimalDetails function for each animal
        for(int i = 0; i < this->numAnimals; i++){

            cout << "\n\t\t\t---------- animal " << (i + 1) << " ----------\n";
            animalArray[i]->printAnimalDetatils();
        }
    }
}

// User wants to display animal names
void Zoo::displayAnimalNames(){

    if(this->numAnimals == 0){
        cout << "\nThere are no animals in your zoo yet.";
    }
    else{
        // Loop through animalArray and enter the getAnimalName function for each animal
        for(int i = 0; i < this->numAnimals; i++){

            cout << "animal " << (i + 1) << ": ";
            cout << animalArray[i]->getAnimalName() << endl << endl;
        }
    }
}


// User wants to remove an animal from the zoo
void Zoo::removeAnimalFromArray(){

    int removeAnimal = 0;

    if(this->numAnimals <=1){
        cout << "There must always be at least one animal in your zoo." << endl;
        cout << "You can't remove any animals right now, or you will have no animals in your zoo" << endl;
    }
    else{
        cout << "\nChoose from the following animals to remove: \n";
        displayAnimalNames();
        cout << "\nChoose an animal to remove between 1 & " << numAnimals << ": ";
        cin >> removeAnimal;

        while(removeAnimal > numAnimals || !cin){// Validate User Input
            cin.clear(); //clears the error state
		        //line below ignores the rest of the current line, up to '\n' or EOF - whichever comes first
		    cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid number: ";
            cin >> removeAnimal;

        }

        string name =  animalArray[removeAnimal - 1]->getAnimalName();
        cout << "\nThe animal " << "'" << name << "' has been successfully deleted.\n\n";

        delete animalArray[removeAnimal - 1]; // Release dynamically allocated space for the animal object

        // Move all array elements in animalArray back 1 space, starting with the deleted animal's element
        for(int i = removeAnimal - 1; i < this->numAnimals-1; i++){
            animalArray[i] = animalArray[i + 1];
        }

        numAnimals--; // Decrement numAnimals
    }
}

// User wants to save the animals in the zoo to a file
void Zoo::saveToFile(string x){

    ofstream outfile;

    outfile.open(x);
    if(outfile.is_open()){
        for(int i = 0; i < numAnimals; i++){
            animalArray[i]->printAnimalDetatilsToFile(outfile);
        }
        cout << "\nAll animals in your zoo have been printed to " << x << endl;
        outfile.close();
    }
}