/******************************************************************************
 
	Title:			prog4.cpp
	Author: 		Anissa Sollman
	Date Created: 	04/22/2025
	Last Updated: 	04/24/2025
	Purpose: 		Finding paths from Wikipedia pages to other Wikipedia pages

*******************************************************************************/
#include "Graph.hpp"

int main(){

    int choice = 0;
    Graph wikiGraph;

    do{
        cout << "\n=== WikiGraph Menu ===";
        cout << "\n1. BFS";
        cout << "\n2. Show first 10 links from an article";
        cout << "\n3. Exit";
        cout << "\nChoice: ";

        cin >> choice;

        switch(choice){

            case 1:
                wikiGraph.search();
            break;

            case 2:
                wikiGraph.firstTen();
            break;

            case 3:
                return 0;

        }
    }while(choice <= 3 && choice >= 1);
}