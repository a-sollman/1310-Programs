#include "json.hpp"
#include <fstream>
#include <iostream>
#include <stack>
using json = nlohmann::json;
using namespace std;

class Graph{
    private:
        unordered_map<string, vector<string>> um; // takes a string as the key, and a vector of string for the value
        int numNodes;
        json jsonObj;

    public:
        Graph(){ // Constructor
            ifstream inputFile("wikipedia_graph.json");
            inputFile >> jsonObj;

            for(auto& [key, value] : jsonObj.items()){
                for(auto& neighbor : value){
                    // For each key, we will add the "neighbors" to our vector of strings
                    // Basically each Wiki page will have pages linked to it which we call neighbors
                    um[key].push_back(neighbor); 
                }
                this->numNodes++; // number of keys / inserted Wiki pages from wikipedia_graph.json
            }
        }
        ~Graph(){
            cout << "\nGoodbye!";
        }
        void search(){

            string article1, article2;

            cout << "\nEnter article: ";
            cin.ignore();
            getline(cin, article1);
            // Checking if article1 is in the graph
            for(int i = 0; i < this->numNodes; i++){
                if(um.find(article1) == um.end()){ // if article1 is not a key
                    cout << "Article not found in graph.\n";
                    return;
                }
            }

            cout << "\nEnter goal article: ";
            getline(cin, article2);

            stack<string> adjacencyList; // stack holds the adjacency list
            vector<string> visited; // vector of already visited links
            vector<string> print; // vector holding the complete path
            bool found = false;

            print.push_back(article1); // First element of path is article1


            // First check article's direct adjacency list for article2
            for(int i = 0; i < um[article1].size(); i++){
                if(um[article1][i] == article2){ // Found article2
                    print.push_back(um[article1][i]);
                    found = true;
                    break;
                }
                else{
                    // If article2 was not in the direct adjacency list, then we will add this link so its direct adjacency list can be checked
                    adjacencyList.push(um[article1][i]);   
                }
            }

            while(found == false && !adjacencyList.empty()){ // While we haven't found article2 and the adjacencyList is not empty

                string neighborArticle = adjacencyList.top(); // We are now checking the adjacencyList elements' neighbors
                adjacencyList.pop(); // Pop it off since we are about to check it
                bool wasVisited = false;

                for(int j = 0; j < visited.size(); j++){
                    if(visited[j] == neighborArticle){
                        wasVisited = true; // If we have visited this article, then we will not check it
                        break;
                    }
                }

                // Next check the neighborArticle's direct adjacency list
                if(wasVisited == false){
                    visited.push_back(neighborArticle); // We are about to check this neighborArticle, so we will add it to our visited vector
                    for(int i = 0; i < um[neighborArticle].size(); i++){

                        if(um[neighborArticle][i] == article2){ // If we found article2 we will break out of loop
                            print.push_back(neighborArticle);
                            print.push_back(um[neighborArticle][i]);
                            found = true;
                            break;
                        }
                        else{
                            // else we will push the neighbors of our neighborArticle to our stack to be checked
                            adjacencyList.push(um[neighborArticle][i]);
                        }
                    }
                }
            }
            if(found == true){ // Printing the path if it exists
                cout << "\nPath from " << article1 << " to " << article2;
                for(int i = 0; i < print.size(); i++){
                    cout << "\n- " << print[i];
                }
                cout << endl;
                return;
            }
            else{ // No path exists if found == false
                cout << "\nPath does not exist";
                return;
            }
        }

        void firstTen(){

            string article;

            cout << "\nEnter article: ";
            cin.ignore();
            getline(cin, article);
            // Checking if article1 is in the graph
            for(int i = 0; i < this->numNodes; i++){
                if(um.find(article) == um.end()){ // if article1 is not a key
                    cout << "Article not found in graph.\n";
                    return;
                }
            }

            cout << "\nFirst 10 links from '" << article << "':";

            for(int i = 0; i < 10; i++){

                cout << endl << "- "<< um[article][i]; // Print hyperlinks
            }
            cout << endl;
        }
};